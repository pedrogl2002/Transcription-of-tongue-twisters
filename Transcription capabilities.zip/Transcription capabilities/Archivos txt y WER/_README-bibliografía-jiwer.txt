Fuente original. Página de GitHub
https://github.com/jitsi/jiwer

Documentación: https://jitsi.github.io/jiwer/

Los parámetros de jiwer.Compose en
https://jitsi.github.io/jiwer/reference/transforms/


Soporte teórico: 
From_WER_and_RIL_to_MER_and_WIL_improved_evaluatio.pdf


Vaessen, N. 2022. JiWER: Similarity measures for
automatic speech recognition evaluation. Version
3.0.3, retrieved 1st April 2024 from
https://pypi.org/project/jiwer/