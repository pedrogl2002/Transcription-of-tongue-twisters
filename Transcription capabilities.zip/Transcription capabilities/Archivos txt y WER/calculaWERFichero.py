finput = input('Input file: ')
try:
    fichero = open(finput)
except:
    print('The file does not exist', finput)
    quit()

print('We work with ', finput)
temp = finput[:len(finput) - 4]
foutput = temp + '-WER.txt'
fichero_salida = open(foutput, 'w')
import jiwer

transforms = jiwer.Compose(
    [
        jiwer.ExpandCommonEnglishContractions(),
        #jiwer.RemoveWhiteSpace(), 
        jiwer.RemoveEmptyStrings(),
        #jiwer.ToLowerCase(),
        jiwer.RemoveMultipleSpaces(),
        jiwer.Strip(),
        #jiwer.RemovePunctuation(),
        jiwer.ReduceToListOfListOfWords(),
    ]
)

referencia = [
"A loyal warrior will rarely worry why we rule." ,
"How much ground would a groundhog hog if a groundhog could hog ground?" ,
"Imagine an imaginary menagerie manager managing an imaginary menagerie." ,
"Lesser leather never weathered wetter weather better." ,
"Top chopstick shops stock top chopsticks."
]


contador = 0
for trabal in fichero:
    hipotesis = trabal.strip()
    ref = referencia[contador % 5]
    wer_ref = jiwer.wer(ref, hipotesis,truth_transform=transforms,hypothesis_transform=transforms,) 
    wer_ref_string = f"{wer_ref:.4f}"+'\n'
    fichero_salida.write(wer_ref_string)
    contador = contador + 1 

fichero_salida.close()
print('Results in', foutput)
