El comando desde PowerShell

$ python3 -m pip install jiwer

sí funciona y permite ejecutar 'import jiwer' desde los programas.

Se puede hacer desde el prompt de Terminal o PowerShell con
$ pip install jiwer



