Whisper
Los datos de Whisper se han extraído de la página web
https://replicate.com/openai/whisper

En la pestaña 'Playground' se puede incorporar un fichero de audio y el sistema lo transcribe. Los parámetros de la ejecución son
- model large-v3
- transcription plain-text
- translate False
- language en
- temperature 0
- patience N/A
- suppress-tokens -1
- initial_prompt ""
- condition_on_previous_text False
- tempreature_increment_on_fallback 0,2
- compression_ratio_threshold 2,4
- logprob_threshold -1
- no_speech_threshold 0,6

Todos los valores son los que aparecen por defecto, SALVO 'language', que hay poner el valor 'en'.

Es necesario realizar 'Sign in' en GitHub para ejecutarlo. Se puede usar el usuario de Gmail. La transcripción aparece en el lado derecho de la pantalla.

La operación se ha realizado con todos los ficheros de audio: A(1), A(2), hasta I(5). La salida se ha copiado de forma sucesiva en el fichero 'Whisper.txt'.

Canary
Los datos de Canary se ha extraído de la página web
https://replicate.com/cjwbw/canary-1b

En la pestaña 'Playgroud' se puede incorporar un fichero de audio y el sistema lo transcribe. Los parámetros de la ejecuión son
- audio_langage en
- tgt_language en
- pnc True

Todos los valores son los que aparecen por defecto. 

Es necesario realizar 'Sign in' en GitHub para ejecutarlo. Se puede usar el usuario de Gmail. La transcripción aparece en el lado derecho de la pantalla.

La operación se ha realizado con todos los ficheros de audio: A(1), A(2), hasta I(5). La salida se ha copiado de forma sucesiva en el fichero 'Canary.txt'.